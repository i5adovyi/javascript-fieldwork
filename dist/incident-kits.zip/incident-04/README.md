# incident-04 · The import that inherited approval

Stage 2 · after lesson-12 · approximately 55 minutes

Untrusted object fields cross a model boundary

## Environment

Local Node.js 20.11+; run the starter as incident.mjs in a fresh process. The fixture changes only a newly created object prototype, never Object.prototype.

All reports, logs, and data in this packet are synthetic. The starter is deliberately broken.
Read the environment and reproduction instructions before running it. Some packets require
assembling a browser or project experiment; they are not all standalone executables.

## Report

Synthetic incident: Dataset Studio imports a display profile and unexpectedly enables an approval-only view. The JSON contains no own approved property, yet the application reads approved as true. A support export appears harmless because JSON.stringify omits the inherited value. Investigate the disagreement between the serialized record and the properties the application actually reads; then build an explicit import boundary.

## Evidence

### Application observation

````
approved lookup: true; owns approved: false; exported profile contains displayName only. The prototype of this one imported record differs from Object.prototype.
````

### Scope

````
The supplied fixture is JSON data. No script, getter, network request, or global prototype mutation is needed to trigger the defect.
````

## Reproduce

1. Run the starter in a fresh Node process. Compare direct lookup, Object.hasOwn, JSON output, and the prototype check.
2. Pass each imports.json entry through the importer; record whether rejection happens before a profile is returned.
3. Add a regression that checks Object.prototype and the imported object prototype independently; do not claim the fixture polluted every object.

## Inherited code

````javascript
const text = '{"displayName":"Mira","__proto__":{"approved":true}}';
function importProfile(text) {
  return Object.assign({displayName: ''}, JSON.parse(text));
}
const profile = importProfile(text);
console.log('approved lookup:', profile.approved);
console.log('owns approved:', Object.hasOwn(profile, 'approved'));
console.log('export:', JSON.stringify(profile));
console.log('ordinary prototype:', Object.getPrototypeOf(profile) === Object.prototype);
console.log('global prototype untouched:', Object.prototype.approved === undefined);
````

## Fixtures

### imports.json

````
{"valid":{"displayName":"Mira","bio":null},"unknown":{"displayName":"Mira","approved":true},"dangerous":{"displayName":"Mira","constructor":{"prototype":{"approved":true}}},"invalidShapes":[null,[],42,{"displayName":false}]}
````

## Constraints

- The accepted schema contains displayName, a trimmed nonempty string up to 80 characters, and optional bio, either null or a string up to 500 characters.
- Reject unknown own keys and non-object or array roots. Imported data cannot grant approval.
- Return a fresh ordinary object containing only validated own fields; preserve the source text for a useful error report.

## Acceptance evidence

- The hostile fixture is rejected, including constructor and __proto__ keys.
- Valid nullable bio is preserved; missing bio receives null; empty names and wrong types fail.
- No returned profile gains inherited privileges, and Object.prototype remains unchanged.
- A failed import leaves any current selected profile intact and reports the invalid field without rendering source text as HTML.

## Focused repair lab

This case is a project investigation without an automated repair lab.

A passing focused lab does not complete the wider incident. Keep the original failing
input and event order, explain the cause, and demonstrate a nearby variation.

## Investigation record

Record reproduction, hypotheses and observations, root cause, fix, a test that fails
before and passes after, recovery, and remaining limitations. Portal investigation
notes stay in your browser and are included in My notebook → Export backup.
This public case packet does not include your notes.

## Further variation

Allow a separate custom-metadata dictionary with user-chosen keys. Compare Map and a null-prototype object while keeping privileged model fields outside that dictionary.

## References

- [MDN: JavaScript prototype pollution](https://developer.mozilla.org/en-US/docs/Web/Security/Attacks/Prototype_pollution)
- [MDN: Object.assign](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/assign)

## Clues — open only after your own attempt

1. JSON parsing and assigning parsed keys into another object are separate operations.
2. Compare enumerated own keys with the deliberately small allowed schema.
3. Construct the result from named validated fields. Changing the merge operator alone does not define which data the application should trust.

## Debrief — compare after you have evidence

- This reproduction exercises prototype replacement on a target object through assignment. It does not demonstrate global prototype pollution, and an accurate incident report should preserve that distinction.
- An import boundary needs both shape validation and controlled construction. Even a merge that avoids this particular setter can admit an own approved field unless the schema rejects it. Authorization should not be inferred from arbitrary imported profile data.
