const text = '{"displayName":"Mira","__proto__":{"approved":true}}';
function importProfile(text) {
  return Object.assign({displayName: ''}, JSON.parse(text));
}
const profile = importProfile(text);
console.log('approved lookup:', profile.approved);
console.log('owns approved:', Object.hasOwn(profile, 'approved'));
console.log('export:', JSON.stringify(profile));
console.log('ordinary prototype:', Object.getPrototypeOf(profile) === Object.prototype);
console.log('global prototype untouched:', Object.prototype.approved === undefined);
