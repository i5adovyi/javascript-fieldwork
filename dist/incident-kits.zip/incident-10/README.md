# incident-10 · Saved on screen, missing after reload

Stage 5 · after lesson-30 · approximately 70 minutes

A failed write reveals the real commit boundary

## Environment

Local Node.js 20.11+ for deterministic storage adapters. Browser continuations use a disposable project origin and synthetic data, never the training portal’s real storage.

All reports, logs, and data in this packet are synthetic. The starter is deliberately broken.
Read the environment and reproduction instructions before running it. Some packets require
assembling a browser or project experiment; they are not all standalone executables.

## Report

Synthetic incident: a note appears saved after the browser refuses persistence. Reload restores the old note. A proposed import fix writes three keys, then attempts rollback; its rollback can fail too. Establish the single-key commit contract first, then use the supplied harder fixtures to explain why multiple writes and multiple tabs need additional coordination.

## Evidence

### Visible versus durable

````
commit throws “Synthetic quota failure”, yet snapshot().notes contains new while the stored JSON still contains old.
````

### Harder continuations

````
rollback-failure.mjs leaves notes and tags new but settings old. two-tabs.mjs ends with only tab B’s edit because both tabs began from the same revision.
````

## Reproduce

1. Run incident.mjs and compare the reported failure with both state representations.
2. Use a cyclic next value to trigger serialization failure before a write. Mutate initial and returned snapshots to probe ownership.
3. Run each continuation independently. Record the exact failed write number and the point at which tab B’s stale snapshot became authoritative.

## Inherited code

````javascript
function createPersistentStore(initial, storage, key) {
  let state = initial;
  return {
    snapshot: () => state,
    commit(next) { state = next; storage.setItem(key, JSON.stringify(next)); return state; }
  };
}
const initial = {notes: ['old']};
const storage = {
  raw: JSON.stringify(initial),
  setItem() { throw new Error('Synthetic quota failure'); }
};
const store = createPersistentStore(initial, storage, 'practice');
try { store.commit({notes: ['new']}); } catch (error) { console.log(error.message); }
console.log('screen:', JSON.stringify(store.snapshot()));
console.log('durable:', storage.raw);
````

## Fixtures

### rollback-failure.mjs

````
const values = {notes: 'old', tags: 'old', settings: 'old'};
let writes = 0;
function setItem(key, value) {
  writes++;
  if (writes === 3 || writes === 4) throw new Error(`write ${writes} failed`);
  values[key] = value;
}
const before = {...values};
try { for (const key of Object.keys(values)) setItem(key, 'new'); }
catch (original) {
  try { for (const key of Object.keys(before)) setItem(key, before[key]); }
  catch (rollback) { console.log(original.message, 'then', rollback.message); }
}
console.log('mixed state:', JSON.stringify(values));
````

### two-tabs.mjs

````
let raw = JSON.stringify({revision: 0, notes: []});
const tabA = JSON.parse(raw);
const tabB = JSON.parse(raw);
tabA.notes.push('edit A'); tabA.revision++;
raw = JSON.stringify(tabA);
tabB.notes.push('edit B'); tabB.revision++;
raw = JSON.stringify(tabB);
console.log('last writer:', raw);
console.log('recoverable A draft:', JSON.stringify(tabA));
````

## Constraints

- Keep createPersistentStore(initial, storage, key), commit(next), and snapshot(); initialization performs no write.
- Commit synchronously serializes and parses JSON, writes that serialized candidate, then publishes its independent in-memory copy.
- The core single-key adapter does not promise multi-key transactions, cross-tab isolation, or crash durability.

## Acceptance evidence

- Serialization or setItem failure leaves the current state unchanged and throws to the caller.
- Successful commit and snapshot return independent JSON copies; caller mutations cannot rewrite owned state.
- Explain why rollback failure cannot honestly be reported as “restored”. Preserve the original and rollback errors.
- For the two-tab continuation, preserve both drafts and propose an explicit conflict policy and coordination mechanism.

## Focused repair lab

Open `#/lab/lab-55` in the portal.

A passing focused lab does not complete the wider incident. Keep the original failing
input and event order, explain the cause, and demonstrate a nearby variation.

## Investigation record

Record reproduction, hypotheses and observations, root cause, fix, a test that fails
before and passes after, recovery, and remaining limitations. Portal investigation
notes stay in your browser and are included in My notebook → Export backup.
This public case packet does not include your notes.

## Further variation

Build the continuation with an IndexedDB transaction and two actual tabs. Detect conflicts without silently erasing either draft; retain a local export path when storage remains unavailable.

## References

- [MDN: Storage.setItem](https://developer.mozilla.org/en-US/docs/Web/API/Storage/setItem)
- [MDN: Using IndexedDB](https://developer.mozilla.org/en-US/docs/Web/API/IndexedDB_API/Using_IndexedDB)
- [MDN: Window storage event](https://developer.mozilla.org/en-US/docs/Web/API/Window/storage_event)

## Clues — open only after your own attempt

1. Locate the first publication of next relative to the operation that can fail.
2. A rollback is another write, so its success must be observed too.
3. A single authoritative envelope simplifies small-state commits; IndexedDB transactions can support larger atomic updates. Cross-tab conflict handling is a separate requirement.

## Debrief — compare after you have evidence

- The screen should reflect the last acknowledged save. The core publishes only after the adapter accepts the same candidate; this establishes its synchronous contract, not a guarantee against every possible device or process failure.
- This does not make localStorage a transactional database. A storage event is a notification, not a lock, and checking a revision before a separate write is not an atomic compare-and-swap.
