function createPersistentStore(initial, storage, key) {
  let state = initial;
  return {
    snapshot: () => state,
    commit(next) { state = next; storage.setItem(key, JSON.stringify(next)); return state; }
  };
}
const initial = {notes: ['old']};
const storage = {
  raw: JSON.stringify(initial),
  setItem() { throw new Error('Synthetic quota failure'); }
};
const store = createPersistentStore(initial, storage, 'practice');
try { store.commit({notes: ['new']}); } catch (error) { console.log(error.message); }
console.log('screen:', JSON.stringify(store.snapshot()));
console.log('durable:', storage.raw);
