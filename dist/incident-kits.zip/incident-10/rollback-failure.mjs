const values = {notes: 'old', tags: 'old', settings: 'old'};
let writes = 0;
function setItem(key, value) {
  writes++;
  if (writes === 3 || writes === 4) throw new Error(`write ${writes} failed`);
  values[key] = value;
}
const before = {...values};
try { for (const key of Object.keys(values)) setItem(key, 'new'); }
catch (original) {
  try { for (const key of Object.keys(before)) setItem(key, before[key]); }
  catch (rollback) { console.log(original.message, 'then', rollback.message); }
}
console.log('mixed state:', JSON.stringify(values));
