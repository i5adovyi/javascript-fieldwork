let raw = JSON.stringify({revision: 0, notes: []});
const tabA = JSON.parse(raw);
const tabB = JSON.parse(raw);
tabA.notes.push('edit A'); tabA.revision++;
raw = JSON.stringify(tabA);
tabB.notes.push('edit B'); tabB.revision++;
raw = JSON.stringify(tabB);
console.log('last writer:', raw);
console.log('recoverable A draft:', JSON.stringify(tabA));
