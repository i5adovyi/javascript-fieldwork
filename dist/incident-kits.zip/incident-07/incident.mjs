function truncateGraphemes(text, limit, suffix = '…') {
  return text.length > limit ? text.slice(0, limit) + suffix : text;
}
for (const text of ['éclair', '🇵🇱 travel', '👍🏽 approved', '👩‍👩‍👧‍👦 notes']) {
  console.log(JSON.stringify(text), '=>', JSON.stringify(truncateGraphemes(text, 1)));
}
console.log('empty:', JSON.stringify(truncateGraphemes('', 0)));
console.log('zero:', JSON.stringify(truncateGraphemes('abc', 0)));
