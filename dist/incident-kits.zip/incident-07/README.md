# incident-07 · The preview cuts a person in half

Stage 4 · after lesson-20 · approximately 40 minutes

Visible characters are not string indexes

## Environment

Local Node.js 20.11+ with Intl.Segmenter, or a modern browser console with that API. Run starter as incident.mjs; report missing capability explicitly.

All reports, logs, and data in this packet are synthetic. The starter is deliberately broken.
Read the environment and reproduction instructions before running it. Some packets require
assembling a browser or project experiment; they are not all standalone executables.

## Report

Synthetic incident: Research Queue shortens article titles for its compact view. English titles look fine, but a family emoji becomes an incomplete symbol, a flag splits, and a decomposed accented letter loses its accent. The product requirement is a limit on user-perceived characters. Determine what the current implementation counts and preserve the original text while producing a safe preview.

## Evidence

### Fixture inventory

````
The examples contain a combining accent, a two-indicator flag, a skin-tone modifier, and a multi-person zero-width-joiner sequence. Each first visible unit should remain intact.
````

### Failure signature

````
slice(0,1) operates on UTF-16 code units. Replacing it with [...text].slice(0,1) fixes surrogate splitting but still does not satisfy every fixture.
````

## Reproduce

1. Run the starter and compare the JSON-escaped output with each expected fixture.
2. Try a code-point implementation using spread syntax and record which cases still fail.
3. Check exactly-at-limit, empty input, zero limit, an empty suffix, and a custom multi-character suffix.

## Inherited code

````javascript
function truncateGraphemes(text, limit, suffix = '…') {
  return text.length > limit ? text.slice(0, limit) + suffix : text;
}
for (const text of ['éclair', '🇵🇱 travel', '👍🏽 approved', '👩‍👩‍👧‍👦 notes']) {
  console.log(JSON.stringify(text), '=>', JSON.stringify(truncateGraphemes(text, 1)));
}
console.log('empty:', JSON.stringify(truncateGraphemes('', 0)));
console.log('zero:', JSON.stringify(truncateGraphemes('abc', 0)));
````

## Fixtures

### grapheme-cases.json

````
[{"text":"éclair","limit":1,"expected":"é…"},{"text":"🇵🇱 travel","limit":1,"expected":"🇵🇱…"},{"text":"👍🏽 approved","limit":1,"expected":"👍🏽…"},{"text":"👩‍👩‍👧‍👦 notes","limit":1,"expected":"👩‍👩‍👧‍👦…"},{"text":"👩‍👩‍👧‍👦","limit":1,"expected":"👩‍👩‍👧‍👦"}]
````

## Constraints

- Keep truncateGraphemes(text, limit, suffix="…"). Both text and suffix are strings; limit is a nonnegative safe integer.
- The suffix is outside the grapheme budget and appears only when content was removed.
- Preserve normalization and original code units; do not silently normalize or strip joining characters.

## Acceptance evidence

- All supplied grapheme clusters survive intact and match the fixture strings exactly.
- A zero limit returns the suffix for nonempty text and an empty string for empty text.
- At-limit input receives no suffix; invalid arguments are rejected.
- The implementation uses feature-detected Intl.Segmenter or clearly reports an unsupported host instead of claiming a code-point fallback is equivalent.

## Focused repair lab

Open `#/lab/lab-52` in the portal.

A passing focused lab does not complete the wider incident. Keep the original failing
input and event order, explain the cause, and demonstrate a nearby variation.

## Investigation record

Record reproduction, hypotheses and observations, root cause, fix, a test that fails
before and passes after, recovery, and remaining limitations. Portal investigation
notes stay in your browser and are included in My notebook → Export backup.
This public case packet does not include your notes.

## Further variation

Investigate a date label across a daylight-saving transition using an explicit IANA time zone. Explain why adding 24 hours and advancing one calendar day are different requirements.

## References

- [MDN: Intl.Segmenter](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/Segmenter)

## Clues — open only after your own attempt

1. Count code units, code points, and grapheme segments for the same family emoji.
2. Intl.Segmenter exposes grapheme segmentation as a host capability.
3. Retain whole segments and detect whether an additional segment exists before deciding to append the suffix.

## Debrief — compare after you have evidence

- A string index is useful for the representation JavaScript exposes, but a product character limit must define its own unit. The fixtures make that choice testable.
- Segmentation preserves a cluster boundary; normalization is a separate transformation. Avoid adding it as an incidental repair because it changes the stored representation and can affect exact comparisons elsewhere.
