function readOptionalInteger(raw, {fallback, min, max}) {
  const value = parseInt(raw, 10) || fallback;
  if (value < min || value > max) throw new RangeError('Outside bounds');
  return value;
}
const options = {fallback: 3, min: 0, max: 5};
for (const raw of [undefined, '0', '  ', '3x', '1e2']) {
  try { console.log(JSON.stringify(raw), '=>', readOptionalInteger(raw, options)); }
  catch (error) { console.log(JSON.stringify(raw), '=>', error.name); }
}
