# incident-01 · Zero retries turns into three

Stage 1 · after lesson-04 · approximately 35 minutes

An optional configuration field hides four different states

## Environment

Local Node.js 20.11+; save the starter as incident.mjs and run node incident.mjs. The parser can also be explored in a browser console.

All reports, logs, and data in this packet are synthetic. The starter is deliberately broken.
Read the environment and reproduction instructions before running it. Some packets require
assembling a browser or project experiment; they are not all standalone executables.

## Report

Synthetic incident: Dispatch accepts a retry count from a text configuration field. An operator explicitly enters zero to disable retries, yet the preview shows three. Another operator enters "3x" and receives no error. Reproduce both reports, distinguish an absent option from an invalid one, and repair the parser before any request or retry loop is connected to it.

## Evidence

### Observed values

````
undefined → 3; "0" → 3; "  " → 3; "3x" → 3; "1e2" → 1. Several different mistakes collapse into apparently valid configuration.
````

### Boundary agreement

````
Only undefined means absent. A supplied string must contain one complete signed decimal integer after trimming. Blank input is a mistake, not a request for the fallback.
````

## Reproduce

1. Run the unchanged starter and compare each line with the boundary agreement.
2. Add the supplied parser cases, recording returned values or exception classes rather than just whether something threw.
3. Test invalid options separately: reversed bounds, fractional fallback, and a fallback outside the interval.

## Inherited code

````javascript
function readOptionalInteger(raw, {fallback, min, max}) {
  const value = parseInt(raw, 10) || fallback;
  if (value < min || value > max) throw new RangeError('Outside bounds');
  return value;
}
const options = {fallback: 3, min: 0, max: 5};
for (const raw of [undefined, '0', '  ', '3x', '1e2']) {
  try { console.log(JSON.stringify(raw), '=>', readOptionalInteger(raw, options)); }
  catch (error) { console.log(JSON.stringify(raw), '=>', error.name); }
}
````

## Fixtures

### parser-cases.json

````
{"options":{"fallback":3,"min":0,"max":5},"accepted":[[" +2 ",2],["-0",0],["05",5]],"typeErrors":["", "  ", "1.0", "0x10", "3x", null, false, 0],"rangeErrors":["-1","6","9007199254740993"]}
````

## Constraints

- Keep the exact readOptionalInteger(raw, options) API used by lab-49.
- Options must be safe integers with min ≤ fallback ≤ max. Supplied raw values must be strings; absence is exactly undefined.
- Reject blank, partial, hexadecimal, fractional, or exponent spellings instead of coercing them.

## Acceptance evidence

- Undefined returns the fallback; "0" and "-0" return ordinary positive zero; surrounding whitespace is permitted.
- Type or syntax failures throw TypeError; unsafe or out-of-range parsed integers throw RangeError.
- Invalid options fail before a fallback or parsed result is returned.
- Your regression table includes absence, valid zero, blank input, partial input, both bounds, and an unsafe integer.

## Focused repair lab

Open `#/lab/lab-49` in the portal.

A passing focused lab does not complete the wider incident. Keep the original failing
input and event order, explain the cause, and demonstrate a nearby variation.

## Investigation record

Record reproduction, hypotheses and observations, root cause, fix, a test that fails
before and passes after, recovery, and remaining limitations. Portal investigation
notes stay in your browser and are included in My notebook → Export backup.
This public case packet does not include your notes.

## Further variation

Add a separate Boolean configuration parser for exact strings "true" and "false". Explain why Boolean("false") cannot implement that contract.

## References

- [MDN: Nullish coalescing operator](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Nullish_coalescing)

## Clues — open only after your own attempt

1. Trace the value produced by parseInt before the logical OR runs.
2. Validation of spelling and validation of numeric range are different decisions.
3. Recognize the entire trimmed decimal spelling, convert once, then check safe-integer bounds. Handle absence explicitly before parsing.

## Debrief — compare after you have evidence

- The fallback operator treated a valid result as missing. Replacing it with another defaulting operator addresses only one symptom; parseInt still accepts a prefix of invalid input.
- A boundary parser should make states visible: absent, valid, malformed, and out of range. The caller can then show a useful configuration error instead of silently choosing a different operating policy.
