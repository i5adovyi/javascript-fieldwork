# incident-02 · Two orders become one

Stage 1 · after lesson-06 · approximately 50 minutes

Identity coercion and a missing cent at the import boundary

## Environment

Local Node.js 20.11+; save starter as incident.mjs and run node incident.mjs. No packages, network, or real customer data.

All reports, logs, and data in this packet are synthetic. The starter is deliberately broken.
Read the environment and reproduction instructions before running it. Some packets require
assembling a browser or project experiment; they are not all standalone executables.

## Report

Synthetic incident: a small dispatch importer accepts order IDs and prices from a text export. Two distinct orders appear under one identity, and a 0.29 delivery surcharge becomes 28 cents. The team suspects duplicate source rows. Your assignment is to preserve the original evidence, locate the first lossy conversion, and define a boundary contract that prevents both failures before pricing rules run.

## Evidence

### Source rows

````
IDs 9007199254740992 and 9007199254740993 are distinct text identifiers. Both rows intentionally use amount 0.29; equal amounts do not imply equal orders.
````

### Observed probe

````
same normalized ID: true; normalized cents: 28; original IDs unchanged: true. The source remains correct while its derived representation is wrong.
````

## Reproduce

1. Run the supplied program and record all three observations before changing code.
2. Inspect Number(rows[0].id), Number(rows[1].id), and Number("0.29") * 100 separately; identify which operation first changes meaning.
3. Repair normalization, then add each boundary-cases.json value to your probe. Compare exact strings and exact integer cents.

## Inherited code

````javascript
const rows = [
  {id: '9007199254740992', amount: '0.29'},
  {id: '9007199254740993', amount: '0.29'}
];
function normalizeOrder(row) {
  return {id: Number(row.id), cents: Math.trunc(Number(row.amount) * 100)};
}
const normalized = rows.map(normalizeOrder);
console.log('same normalized ID:', normalized[0].id === normalized[1].id);
console.log('normalized cents:', normalized[0].cents);
console.log('original IDs unchanged:', rows[0].id !== rows[1].id);
````

## Fixtures

### boundary-cases.json

````
{"accepted":[{"id":"0007","amount":"0.00"},{"id":"9007199254740993","amount":"999999.99"}],"rejectedAmounts":["1.005","1e2"," 1.00","-0.01","Infinity",""],"distinctIds":["0007","7"]}
````

## Constraints

- IDs are opaque nonempty strings; preserve leading zeros and every digit.
- Prices use unsigned decimal text with exactly two fractional digits, from 0.00 through 999999.99. Reject other spellings; never silently round them.
- Do not edit the fixtures or compensate by subtracting a guessed epsilon.

## Acceptance evidence

- The two long IDs and the pair "0007"/"7" remain distinct.
- 0.29 becomes 29 cents; 999999.99 becomes 99999999 cents; every rejected amount throws a useful boundary error.
- Normalization leaves inputs unchanged and returns a safe integer cents field.
- Submit a regression probe that fails on the original implementation and a short explanation separating identity from quantity.

## Focused repair lab

This case is a project investigation without an automated repair lab.

A passing focused lab does not complete the wider incident. Keep the original failing
input and event order, explain the cause, and demonstrate a nearby variation.

## Investigation record

Record reproduction, hypotheses and observations, root cause, fix, a test that fails
before and passes after, recovery, and remaining limitations. Portal investigation
notes stay in your browser and are included in My notebook → Export backup.
This public case packet does not include your notes.

## Further variation

Add negative refunds and currencies with zero or three fractional digits. Specify their grammar and scale first; do not assume every currency uses two digits.

## References

- [MDN: Number.isSafeInteger](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number/isSafeInteger)

## Clues — open only after your own attempt

1. Ask whether arithmetic is meaningful for an order ID.
2. Write the accepted price grammar before choosing a conversion function.
3. Once the decimal spelling is validated, combine whole-unit digits and two fractional digits using integer arithmetic within the stated range.

## Debrief — compare after you have evidence

- The visible duplicate was created downstream. Converting an opaque identifier into a Number discarded information before equality was tested; changing the equality operator cannot restore it.
- A decimal price boundary is a representation decision. Exact integer cents work here because the grammar and maximum are bounded. Keep that contract beside the parser so later developers cannot accidentally broaden it with parseFloat.
