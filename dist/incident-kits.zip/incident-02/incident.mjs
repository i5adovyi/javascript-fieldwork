const rows = [
  {id: '9007199254740992', amount: '0.29'},
  {id: '9007199254740993', amount: '0.29'}
];
function normalizeOrder(row) {
  return {id: Number(row.id), cents: Math.trunc(Number(row.amount) * 100)};
}
const normalized = rows.map(normalizeOrder);
console.log('same normalized ID:', normalized[0].id === normalized[1].id);
console.log('normalized cents:', normalized[0].cents);
console.log('original IDs unchanged:', rows[0].id !== rows[1].id);
