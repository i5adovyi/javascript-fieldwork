# incident-05 · One failed cleanup leaves the room open

Stage 3 · after lesson-17 · approximately 50 minutes

Resource ownership needs a dependable closing contract

## Environment

Local Node.js 20.11+; run the starter as incident.mjs. Synchronous cleanup callbacks represent listeners, worker handles, and subscriptions without creating real timers.

All reports, logs, and data in this packet are synthetic. The starter is deliberately broken.
Read the environment and reproduction instructions before running it. Some packets require
assembling a browser or project experiment; they are not all standalone executables.

## Report

Synthetic incident: reopening an SDK-backed panel produces duplicate notifications. The close operation reports one error, yet older resources remain registered. A second close repeats some cleanup work. Investigate the supplied execution trace and implement a resource scope whose lifecycle remains understandable even when one collaborator throws during teardown.

## Evidence

### Observed first close

````
Execution starts with bus, then renderer throws. Worker cleanup never runs. Registration order leaks into teardown order.
````

### Observed second close

````
Bus and renderer run again. The API has no completed-close state, so callers cannot safely close during both error recovery and ordinary navigation.
````

## Reproduce

1. Run the starter and compare both traces with the checklist; identify the abandoned resource after the first error.
2. Replace two callbacks with distinct Error objects and check both identity and ordering in the repaired AggregateError.errors array.
3. Add a cleanup that calls scope.close() itself. Verify the trace stays finite without timers or recursion guards in the fixture.

## Inherited code

````javascript
function createResourceScope() {
  const cleanups = [];
  return {
    add(cleanup) { cleanups.push(cleanup); },
    close() { for (const cleanup of cleanups) cleanup(); }
  };
}
const calls = [];
const scope = createResourceScope();
scope.add(() => calls.push('bus'));
scope.add(() => { calls.push('renderer'); throw new Error('renderer failed'); });
scope.add(() => calls.push('worker'));
for (let attempt = 1; attempt <= 2; attempt++) {
  try { scope.close(); } catch (error) { console.log('close error:', error.message); }
  console.log('attempt', attempt, JSON.stringify(calls));
}
````

## Fixtures

### lifecycle-checklist.txt

````
Acquire order: bus, renderer, worker.
Required teardown order: worker, renderer, bus.
A callback may call close() again: no callback may repeat.
Two callbacks may throw: preserve both error objects in teardown order.
Adding a cleanup after close has started must fail.
Registering the same function twice represents two registrations.
````

## Constraints

- Keep createResourceScope() with add(syncCleanup) and close(). Asynchronous cleanup is outside this contract.
- Each successful registration runs exactly once; teardown is last-in, first-out.
- Reject nonfunctions and additions after closing begins. A repeated close is a no-op.

## Acceptance evidence

- The initial close attempts worker, renderer, then bus despite the renderer failure.
- After all callbacks run, failure is reported as AggregateError containing original thrown values in execution order.
- A second or reentrant close performs no extra work and does not replay a previous error.
- Closing an empty scope succeeds, and separate scopes have independent lifetimes.

## Focused repair lab

Open `#/lab/lab-51` in the portal.

A passing focused lab does not complete the wider incident. Keep the original failing
input and event order, explain the cause, and demonstrate a nearby variation.

## Investigation record

Record reproduction, hypotheses and observations, root cause, fix, a test that fails
before and passes after, recovery, and remaining limitations. Portal investigation
notes stay in your browser and are included in My notebook → Export backup.
This public case packet does not include your notes.

## Further variation

Design an asynchronous closeAsync variant with explicitly sequential cleanup and a returned completion promise. Specify repeated-close behavior before adding concurrency.

## References

- [MDN: AggregateError](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/AggregateError)

## Clues — open only after your own attempt

1. A resource acquired later may depend on one acquired earlier.
2. Decide when the scope becomes closed relative to invoking arbitrary callbacks.
3. Detach the work list, mark the scope closed, drain it in reverse order, and report collected errors only after every registration has been attempted.

## Debrief — compare after you have evidence

- Cleanup failure should not abandon unrelated cleanup. Continuing teardown and preserving its errors gives the caller both better resource hygiene and more complete evidence.
- Idempotence belongs to the scope contract, not to hopeful assumptions about each collaborator. Marking the lifecycle transition before invoking callbacks also prevents reentrant close calls from replaying work.
