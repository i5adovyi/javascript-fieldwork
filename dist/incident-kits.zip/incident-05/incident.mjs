function createResourceScope() {
  const cleanups = [];
  return {
    add(cleanup) { cleanups.push(cleanup); },
    close() { for (const cleanup of cleanups) cleanup(); }
  };
}
const calls = [];
const scope = createResourceScope();
scope.add(() => calls.push('bus'));
scope.add(() => { calls.push('renderer'); throw new Error('renderer failed'); });
scope.add(() => calls.push('worker'));
for (let attempt = 1; attempt <= 2; attempt++) {
  try { scope.close(); } catch (error) { console.log('close error:', error.message); }
  console.log('attempt', attempt, JSON.stringify(calls));
}
