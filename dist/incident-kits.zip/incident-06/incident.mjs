import {catalog, replaceCatalog} from './catalog.mjs';
import {priceFor} from './prices.mjs';
console.log('first', priceFor('pen'));
replaceCatalog([{id: 'pen', cents: 175}]);
console.log('after replacement', priceFor('pen'));
catalog.rows[0].cents = 999;
console.log('after external mutation', priceFor('pen'));
