import {catalog} from './catalog.mjs';
const cache = new Map();
export function priceFor(id) {
  if (!cache.has(id)) cache.set(id, catalog.rows.find(row => row.id === id));
  return cache.get(id)?.cents ?? null;
}
