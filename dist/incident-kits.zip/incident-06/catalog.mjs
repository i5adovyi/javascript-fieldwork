export const catalog = {rows: [{id: 'pen', cents: 100}]};
export function replaceCatalog(rows) { catalog.rows = rows; }
