# incident-06 · A price that survives its replacement

Stage 3 · after lesson-18 · approximately 60 minutes

Cache invalidation exposes unclear module ownership

## Environment

Local Node.js 20.11+ with ES modules. Save the starter as incident.mjs and the two supplied .mjs files beside it; run node incident.mjs.

All reports, logs, and data in this packet are synthetic. The starter is deliberately broken.
Read the environment and reproduction instructions before running it. Some packets require
assembling a browser or project experiment; they are not all standalone executables.

## Report

Synthetic incident: an SDK returns an old price after a catalog refresh. A caller can also change catalog data without calling any update method. The team proposes clearing every cache whenever a module renders. Identify the actual state owner, make updates observable there, and prove that every public mutation path preserves lookup consistency.

## Evidence

### Deterministic transcript

````
first 100; after replacement 100; after external mutation 100. The catalog refresh contains 175, then a caller writes 999 through the exported rows array.
````

### Design clue

````
The cache key contains an item ID but no catalog revision. Both the catalog container and cached record references escape their modules.
````

## Reproduce

1. Run the three-file reproduction and draw the references held by catalog.rows and the cache after replacement.
2. Add a replacement where pen is removed, then a replacement where pen returns at 220 cents; query after each operation.
3. Attempt to mutate both the caller-owned replacement array and a value returned from your repaired public API.

## Inherited code

````javascript
import {catalog, replaceCatalog} from './catalog.mjs';
import {priceFor} from './prices.mjs';
console.log('first', priceFor('pen'));
replaceCatalog([{id: 'pen', cents: 175}]);
console.log('after replacement', priceFor('pen'));
catalog.rows[0].cents = 999;
console.log('after external mutation', priceFor('pen'));
````

## Fixtures

### catalog.mjs

````
export const catalog = {rows: [{id: 'pen', cents: 100}]};
export function replaceCatalog(rows) { catalog.rows = rows; }
````

### prices.mjs

````
import {catalog} from './catalog.mjs';
const cache = new Map();
export function priceFor(id) {
  if (!cache.has(id)) cache.set(id, catalog.rows.find(row => row.id === id));
  return cache.get(id)?.cents ?? null;
}
````

## Constraints

- Keep catalog state behind a narrow module API; no DOM hook or global refresh bus may be required for correctness.
- Validate all replacement rows before publishing them: unique string IDs and nonnegative safe integer cents.
- Choose either explicit invalidation or revision-aware caching. Explain why retaining the cache is useful at this scale.

## Acceptance evidence

- The initial, replaced, removed, and restored prices are 100, 175, null, and 220.
- Invalid replacement preserves the complete previous catalog and cache behavior.
- Mutation of caller-owned input or a returned snapshot cannot silently rewrite owned catalog state.
- Two independent catalog instances do not share cache entries; tests can construct fresh ownership without reloading the process.

## Focused repair lab

This case is a project investigation without an automated repair lab.

A passing focused lab does not complete the wider incident. Keep the original failing
input and event order, explain the cause, and demonstrate a nearby variation.

## Investigation record

Record reproduction, hypotheses and observations, root cause, fix, a test that fails
before and passes after, recovery, and remaining limitations. Portal investigation
notes stay in your browser and are included in My notebook → Export backup.
This public case packet does not include your notes.

## Further variation

Add an asynchronous price loader. Prove that an old revision resolving after replacement cannot repopulate the current cache; distinguish this race from ordinary synchronous invalidation.

## References

- [MDN: JavaScript modules](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules)

## Clues — open only after your own attempt

1. An imported binding being live does not make a Map entry automatically recompute.
2. List every way a caller can currently change the data, including shared references.
3. Put the revision or invalidation decision next to the successful catalog update; a factory can isolate state for separate SDK consumers.

## Debrief — compare after you have evidence

- The stale result is evidence of two owners believing they control the same fact. A cache must have a clear relationship to the lifetime or revision of its source.
- A module API is also a reference boundary. Copying the array alone still shares its row objects. Decide what may escape, and test that decision. Removing unnecessary caching can be a sound repair if it satisfies the performance requirements.
