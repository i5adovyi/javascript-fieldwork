# Fieldwork incident workshop

12 original synthetic incidents across six stages.
Read each case's README.md for its environment, prerequisites, reproduction, and evidence requirements.
The starter is deliberately broken. The eight linked repair labs run in the portal;
other experiments need your local Node or browser project as described in each packet.

No book content or personal investigation notes are included.
