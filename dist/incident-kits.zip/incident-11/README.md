# incident-11 · One rejected write stops the queue

Stage 6 · after lesson-32 · approximately 70 minutes

Preserve each outcome while keeping later work alive

## Environment

Local Node.js 20.11+; run the starter as incident.mjs. The supplied extension uses Node’s built-in streams and an original in-memory NDJSON source.

All reports, logs, and data in this packet are synthetic. The starter is deliberately broken.
Read the environment and reproduction instructions before running it. Some packets require
assembling a browser or project experiment; they are not all standalone executables.

## Report

Synthetic incident: Signal Desk serializes writes to keep an export ordered. The first write fails, and every later submission rejects with the same error even though its writer was never called. The shutdown path also rejects while waiting for the queue to drain. Repair scheduling separately from individual outcomes, then investigate what an interrupted streaming source may safely claim to have committed.

## Evidence

### Observed queue trace

````
writer calls: ["first"]; outcomes: ["rejected","rejected","rejected"]; idle rejects. Only the first submission actually reached the writer.
````

### Streaming extension

````
The source yields one complete record and a partial second line, then throws. A finally block reports source closure. The partial tail is not an acknowledged record.
````

## Reproduce

1. Run the starter and distinguish submissions rejected by their own writer from submissions whose writer never ran.
2. Add a synchronous-throwing writer and a deferred writer you settle explicitly to verify FIFO and maximum concurrency one.
3. Run interrupted-source.mjs; then implement a line consumer that records complete committed IDs and reports the failed tail separately.

## Inherited code

````javascript
function createWriteQueue(write) {
  let tail = Promise.resolve();
  return {
    enqueue(value) { tail = tail.then(() => write(value)); return tail; },
    idle() { return tail; }
  };
}
const calls = [];
const queue = createWriteQueue(async value => {
  calls.push(value);
  if (value === 'first') throw new Error('Synthetic first-write failure');
  return `stored:${value}`;
});
const pending = ['first', 'second', 'third'].map(value => queue.enqueue(value));
const outcomes = await Promise.allSettled(pending);
console.log('writer calls:', JSON.stringify(calls));
console.log('outcomes:', JSON.stringify(outcomes.map(result => result.status)));
try { await queue.idle(); console.log('idle resolved'); }
catch { console.log('idle rejected'); }
````

## Fixtures

### interrupted-source.mjs

````
import {Readable} from 'node:stream';
async function* chunks() {
  try {
    yield Buffer.from('{"id":1,"title":"complete"}\n');
    yield Buffer.from('{"id":2,"title":"unfinished');
    throw new Error('Synthetic source interruption');
  } finally { console.log('source closed'); }
}
try {
  for await (const chunk of Readable.from(chunks())) {
    console.log('received bytes:', chunk.length, JSON.stringify(chunk.toString('utf8')));
  }
} catch (error) { console.log('source failure:', error.message); }
````

### queue-contract.txt

````
FIFO starts, at most one active writer.
Each enqueue result preserves that writer's own return value or rejection.
A synchronous writer throw is a rejection of that submission only.
idle() never rejects and waits for submissions present when idle() was called.
A later submission does not extend an already-created idle() barrier.
````

## Constraints

- Keep createWriteQueue(write), enqueue(value), and idle(); preserve the lab-56 snapshot-barrier contract.
- Use promise gates to control ordering; do not depend on sleeps or successful real disk writes.
- For the streaming continuation, bound pending line bytes and await each queued commit to prevent unbounded buffering.

## Acceptance evidence

- The core calls all three writers in order; only first rejects, and idle resolves after the initial submissions settle.
- Each caller observes its own value or original error; a failed scheduling tail cannot poison future work.
- An idle barrier created before a later submission does not wait for that later submission.
- The extension reports the interrupted source, closes resources, and never promotes the incomplete second record to committed state.

## Focused repair lab

Open `#/lab/lab-56` in the portal.

A passing focused lab does not complete the wider incident. Keep the original failing
input and event order, explain the cause, and demonstrate a nearby variation.

## Investigation record

Record reproduction, hypotheses and observations, root cause, fix, a test that fails
before and passes after, recovery, and remaining limitations. Portal investigation
notes stay in your browser and are included in My notebook → Export backup.
This public case packet does not include your notes.

## Further variation

Add UTF-8 splits, CRLF splits, a 64 KiB line limit, and a replayed final acknowledged ID. Design a checkpoint and deduplication policy before claiming safe restart after interruption.

## References

- [MDN: Promise.then](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise/then)
- [Node.js: Streams](https://nodejs.org/api/stream.html)
- [MDN: TextDecoder.decode](https://developer.mozilla.org/en-US/docs/Web/API/TextDecoder/decode)

## Clues — open only after your own attempt

1. One promise currently carries both a caller’s outcome and permission to start the next job.
2. The internal scheduling tail may recover while the original result promise still rejects.
3. Capture the current tail when idle is called. For streaming, track parsed, submitted, and successfully committed records separately.

## Debrief — compare after you have evidence

- Recovering the internal tail keeps the queue usable; returning that recovered promise to every caller would instead conceal failed writes. The two responsibilities need separate promises.
- Streaming adds another boundary: a complete parsed record is still not a committed record until its write succeeds. Failure reports and restart checkpoints should reflect that distinction.
