function createWriteQueue(write) {
  let tail = Promise.resolve();
  return {
    enqueue(value) { tail = tail.then(() => write(value)); return tail; },
    idle() { return tail; }
  };
}
const calls = [];
const queue = createWriteQueue(async value => {
  calls.push(value);
  if (value === 'first') throw new Error('Synthetic first-write failure');
  return `stored:${value}`;
});
const pending = ['first', 'second', 'third'].map(value => queue.enqueue(value));
const outcomes = await Promise.allSettled(pending);
console.log('writer calls:', JSON.stringify(calls));
console.log('outcomes:', JSON.stringify(outcomes.map(result => result.status)));
try { await queue.idle(); console.log('idle resolved'); }
catch { console.log('idle rejected'); }
