import {Readable} from 'node:stream';
async function* chunks() {
  try {
    yield Buffer.from('{"id":1,"title":"complete"}\n');
    yield Buffer.from('{"id":2,"title":"unfinished');
    throw new Error('Synthetic source interruption');
  } finally { console.log('source closed'); }
}
try {
  for await (const chunk of Readable.from(chunks())) {
    console.log('received bytes:', chunk.length, JSON.stringify(chunk.toString('utf8')));
  }
} catch (error) { console.log('source failure:', error.message); }
