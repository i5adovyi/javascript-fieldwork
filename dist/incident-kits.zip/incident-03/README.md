# incident-03 · A rejected edit still changes the profile

Stage 2 · after lesson-07 · approximately 45 minutes

Missing, null, and invalid fields require one atomic decision

## Environment

Local Node.js 20.11+; run the starter as incident.mjs. Treat objects as the model boundary; no form or database is required.

All reports, logs, and data in this packet are synthetic. The starter is deliberately broken.
Read the environment and reproduction instructions before running it. Some packets require
assembling a browser or project experiment; they are not all standalone executables.

## Report

Synthetic incident: a profile editor reports that an update failed, but the display name has already changed. Separately, clearing the biography with null has no effect. The application uses the same patch function for autosave and manual edits. Determine which distinctions the patch contract lost and ensure that a rejected update cannot partially modify the current profile.

## Evidence

### First report

````
patch {displayName:"  New name  ",notifications:"yes"} throws TypeError, but the original displayName becomes "New name".
````

### Second report

````
patch {bio:null} keeps the previous biography. An inherited displayName is also currently treated as an instruction.
````

## Reproduce

1. Run the two reported failures, retaining a serialized copy of current before each operation.
2. Exercise inherited, undefined, unknown, symbol, and accessor patches from the supplied module. Check whether the accessor runs.
3. After a successful patch, mutate the returned top-level fields and confirm the old profile remains unchanged.

## Inherited code

````javascript
function patchProfile(current, patch) {
  if (patch.displayName) current.displayName = patch.displayName.trim();
  if (patch.bio) current.bio = patch.bio;
  if ('notifications' in patch) {
    if (typeof patch.notifications !== 'boolean') throw new TypeError('notifications');
    current.notifications = patch.notifications;
  }
  return current;
}
const current = {displayName: 'Mira', bio: 'Original bio', notifications: false};
try { patchProfile(current, {displayName: '  New name  ', notifications: 'yes'}); }
catch (error) { console.log('rejected:', error.name); }
console.log('after rejected patch:', JSON.stringify(current));
console.log('after clear:', JSON.stringify(patchProfile(current, {bio: null})));
````

## Fixtures

### adversarial-patches.mjs

````
export const inherited = Object.create({displayName: 'Inherited'});
export const explicitUndefined = {bio: undefined};
export const unknown = {role: 'administrator'};
export const symbol = {[Symbol('hidden')]: true};
export function accessorProbe() {
  let reads = 0;
  const patch = Object.defineProperty({}, 'bio', {enumerable: true, get() { reads++; return 'side effect'; }});
  return {patch, reads: () => reads};
}
````

## Constraints

- Keep patchProfile(current, patch); current is a valid profile containing displayName, bio, and notifications.
- Inspect only own data properties; inherited fields are ignored. Reject unknown keys, symbols, accessors, and explicit undefined.
- displayName is a trimmed nonblank string, bio is a string or null, and notifications is Boolean.

## Acceptance evidence

- A missing field retains its old value; bio:null clears the biography; notifications:false is applied.
- Any invalid field rejects the whole patch without changing either input.
- Every success returns a fresh object, including an empty patch.
- The accessor probe is rejected without invoking its getter, and inherited values never become edits.

## Focused repair lab

Open `#/lab/lab-50` in the portal.

A passing focused lab does not complete the wider incident. Keep the original failing
input and event order, explain the cause, and demonstrate a nearby variation.

## Investigation record

Record reproduction, hypotheses and observations, root cause, fix, a test that fails
before and passes after, recovery, and remaining limitations. Portal investigation
notes stay in your browser and are included in My notebook → Export backup.
This public case packet does not include your notes.

## Further variation

Add nested contact settings. Define shallow versus recursive patch behavior and test reference ownership before introducing a generic deep-merge helper.

## References

- [MDN: Object.assign and property assignment behavior](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/assign)

## Clues — open only after your own attempt

1. Property absence is not the same thing as a falsy value.
2. Find the first write to current and ask what validation can still fail afterward.
3. Inspect property descriptors, validate the complete patch, and construct the replacement only after all checks succeed.

## Debrief — compare after you have evidence

- A patch is a small command language: an absent key says keep, while an allowed explicit null says clear. Truthiness cannot express those instructions.
- Atomicity here is local and synchronous: validate first, publish one replacement afterward. It does not imply a database transaction. Rejecting accessors also keeps validation from accidentally executing caller-supplied behavior while inspecting a patch.
