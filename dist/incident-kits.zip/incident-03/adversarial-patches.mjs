export const inherited = Object.create({displayName: 'Inherited'});
export const explicitUndefined = {bio: undefined};
export const unknown = {role: 'administrator'};
export const symbol = {[Symbol('hidden')]: true};
export function accessorProbe() {
  let reads = 0;
  const patch = Object.defineProperty({}, 'bio', {enumerable: true, get() { reads++; return 'side effect'; }});
  return {patch, reads: () => reads};
}
