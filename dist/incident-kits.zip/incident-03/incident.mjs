function patchProfile(current, patch) {
  if (patch.displayName) current.displayName = patch.displayName.trim();
  if (patch.bio) current.bio = patch.bio;
  if ('notifications' in patch) {
    if (typeof patch.notifications !== 'boolean') throw new TypeError('notifications');
    current.notifications = patch.notifications;
  }
  return current;
}
const current = {displayName: 'Mira', bio: 'Original bio', notifications: false};
try { patchProfile(current, {displayName: '  New name  ', notifications: 'yes'}); }
catch (error) { console.log('rejected:', error.name); }
console.log('after rejected patch:', JSON.stringify(current));
console.log('after clear:', JSON.stringify(patchProfile(current, {bio: null})));
