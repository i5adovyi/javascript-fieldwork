# incident-09 · The API returned a login page

Stage 5 · after lesson-28 · approximately 50 minutes

Separate HTTP status, media type, parsing, and transport evidence

## Environment

Local Node.js 20.11+ with supplied response adapters. The same core runs in the browser Worker lab; no external API, credentials, or CORS configuration is required.

All reports, logs, and data in this packet are synthetic. The starter is deliberately broken.
Read the environment and reproduction instructions before running it. Some packets require
assembling a browser or project experiment; they are not all standalone executables.

## Report

Synthetic incident: Field Notes reports “invalid JSON” after a session expires. A captured response has status 200 and a login HTML document, while a different failure has status 503 with valid JSON. Support calls both cases a network outage. Diagnose the evidence at each boundary and return a classification that lets the UI explain what actually failed.

## Evidence

### Login capture

````
Status: 200. Content-Type: text/html; charset=utf-8. Body starts with <!doctype html><title>Sign in</title>. Successful HTTP status does not make this an API JSON response.
````

### Transport distinction

````
A rejected fetch may expose no response at all. A generic TypeError alone does not prove CORS; browser network/console evidence is needed. The core fixture instead models already-received responses.
````

## Reproduce

1. Run the starter. Identify the 503 response incorrectly treated as success and the login page mislabeled as malformed JSON.
2. Add the body-read failure fixture; compare its original error object with the returned error.
3. Count text() calls for every case, including HTTP and media-type rejection.

## Inherited code

````javascript
async function readJSONResponse(response) {
  try { return {ok: true, status: response.status, data: JSON.parse(await response.text())}; }
  catch (error) { return {ok: false, status: response.status, kind: 'json', error}; }
}
const fixtures = [
  {name: 'login', status: 200, contentType: 'text/html', body: '<!doctype html><title>Sign in</title>'},
  {name: 'unavailable', status: 503, contentType: 'application/json', body: '{"retry":true}'},
  {name: 'invalid', status: 200, contentType: 'application/json', body: '{broken'},
  {name: 'vendor', status: 200, contentType: 'Application/Problem+JSON; charset=utf-8', body: '{"detail":"example"}'},
  {name: 'empty', status: 204, contentType: 'application/json', body: ''}
];
for (const fixture of fixtures) {
  let reads = 0;
  const result = await readJSONResponse({...fixture, text: async () => { reads++; return fixture.body; }});
  console.log(fixture.name, result.ok ? 'ok' : result.kind, 'body reads:', reads);
}
````

## Fixtures

### read-failure.mjs

````
export const bodyError = new Error('Synthetic body reader disconnected');
export const response = {status: 200, contentType: 'application/json', text() { throw bodyError; }};
export const transportError = new TypeError('Synthetic fetch rejection: cause intentionally unknown');
````

## Constraints

- Keep the plain {status,contentType,text} adapter and result contract from lab-54.
- Classify non-2xx as http before reading. For 2xx, accept application/json and application/*+json, ignoring case and parameters.
- A malformed adapter throws TypeError; do not insert response bodies into HTML or claim a CORS diagnosis from an error name.

## Acceptance evidence

- Login → content-type; 503 → http; malformed JSON and empty 204 JSON body → json; vendor JSON → success.
- Rejected HTTP status or content type causes zero body reads; accepted responses are read exactly once.
- Body-reader rejection returns kind read with the original error.
- Document a separate transport-error path for a fetch that rejects before supplying any response.

## Focused repair lab

Open `#/lab/lab-54` in the portal.

A passing focused lab does not complete the wider incident. Keep the original failing
input and event order, explain the cause, and demonstrate a nearby variation.

## Investigation record

Record reproduction, hypotheses and observations, root cause, fix, a test that fails
before and passes after, recovery, and remaining limitations. Portal investigation
notes stay in your browser and are included in My notebook → Export backup.
This public case packet does not include your notes.

## Further variation

Add a real same-origin test server with JSON, HTML-login, redirect, and 503 routes. Inspect the final response URL; keep credentials and external services out of the reproduction.

## References

- [MDN: Using the Fetch API](https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch)
- [MDN: Response.json](https://developer.mozilla.org/en-US/docs/Web/API/Response/json)

## Clues — open only after your own attempt

1. Check the response contract before deciding to invoke the body reader.
2. An empty successful response and a successful JSON response are different API promises.
3. Keep status checks, media-type checks, body reading, and JSON parsing as separate decision points.

## Debrief — compare after you have evidence

- The same visible error message concealed different repair owners: authentication routing, service availability, and malformed payloads. A useful classification preserves that distinction.
- The adapter intentionally avoids real network timing. Manual browser integration should add evidence about redirects, final URL, and fetch rejection without guessing that every transport failure is CORS.
