export const bodyError = new Error('Synthetic body reader disconnected');
export const response = {status: 200, contentType: 'application/json', text() { throw bodyError; }};
export const transportError = new TypeError('Synthetic fetch rejection: cause intentionally unknown');
