async function readJSONResponse(response) {
  try { return {ok: true, status: response.status, data: JSON.parse(await response.text())}; }
  catch (error) { return {ok: false, status: response.status, kind: 'json', error}; }
}
const fixtures = [
  {name: 'login', status: 200, contentType: 'text/html', body: '<!doctype html><title>Sign in</title>'},
  {name: 'unavailable', status: 503, contentType: 'application/json', body: '{"retry":true}'},
  {name: 'invalid', status: 200, contentType: 'application/json', body: '{broken'},
  {name: 'vendor', status: 200, contentType: 'Application/Problem+JSON; charset=utf-8', body: '{"detail":"example"}'},
  {name: 'empty', status: 204, contentType: 'application/json', body: ''}
];
for (const fixture of fixtures) {
  let reads = 0;
  const result = await readJSONResponse({...fixture, text: async () => { reads++; return fixture.body; }});
  console.log(fixture.name, result.ok ? 'ok' : result.kind, 'body reads:', reads);
}
