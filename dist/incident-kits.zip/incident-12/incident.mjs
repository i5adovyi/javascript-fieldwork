const storage = {raw: JSON.stringify({schema: 1, revision: 4,
  notes: [{id: 'n1', title: 'Read streams'}]})};
function oldClient(store) {
  const draft = JSON.parse(store.raw);
  return {save(title) {
    draft.notes[0].title = title;
    store.raw = JSON.stringify({schema: 1, revision: draft.revision + 1, notes: draft.notes});
  }};
}
const oldTab = oldClient(storage);
const beforeMigration = storage.raw;
storage.raw = JSON.stringify({schema: 2, revision: 5,
  items: [{id: 'n1', title: 'Read streams', archived: true}]});
const afterMigration = storage.raw;
oldTab.save('Read streams carefully');
console.log('before migration:', beforeMigration);
console.log('after migration:', afterMigration);
console.log('after stale save:', storage.raw);
