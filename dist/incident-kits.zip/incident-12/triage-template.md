# Synthetic release incident
Observed trigger:
Confirmed impact and unknown scope:
Evidence preserved (schema, revision, build, original bytes):
Immediate containment for already-running clients:
Recovery choices requiring the user's decision:
Compatibility change for future clients:
Regression evidence:
Rollout and rollback conditions:
