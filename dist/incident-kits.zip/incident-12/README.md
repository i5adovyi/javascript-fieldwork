# incident-12 · Yesterday’s tab writes today’s schema

Stage 6 · after lesson-36 · approximately 90 minutes

Release compatibility, recovery evidence, and honest incident triage

## Environment

Local Node.js 20.11+; the in-memory adapter deterministically represents two browser releases sharing one persistence key. No live deployment or user storage is touched.

All reports, logs, and data in this packet are synthetic. The starter is deliberately broken.
Read the environment and reproduction instructions before running it. Some packets require
assembling a browser or project experiment; they are not all standalone executables.

## Report

Synthetic incident: release 2 migrates notes to an items collection and adds archive state. A tab opened before deployment later saves its old draft. Archive state disappears and the schema number moves backwards. Preserve the supplied snapshots, then distinguish a repair for future clients from containment that can actually protect against already-running old code.

## Evidence

### Release timeline

````
T1 old tab loads schema 1, revision 4. T2 new release writes schema 2, revision 5 with archived:true. T3 old tab saves schema 1, revision 5. Equal revisions now describe incompatible data.
````

### Impact boundary

````
Only the shared local key is modeled. A service worker or refreshed HTML cannot retroactively change JavaScript already executing in the old tab.
````

## Reproduce

1. Run the program and retain all three raw snapshots before attempting recovery. Identify fields that each snapshot can still supply.
2. Modify a future-compatible client to reread and validate schema/revision at commit time; replay the ordered timeline.
3. Replay the original unmodified oldClient against your proposed deployment containment. Record honestly whether it can still overwrite the authoritative new state.

## Inherited code

````javascript
const storage = {raw: JSON.stringify({schema: 1, revision: 4,
  notes: [{id: 'n1', title: 'Read streams'}]})};
function oldClient(store) {
  const draft = JSON.parse(store.raw);
  return {save(title) {
    draft.notes[0].title = title;
    store.raw = JSON.stringify({schema: 1, revision: draft.revision + 1, notes: draft.notes});
  }};
}
const oldTab = oldClient(storage);
const beforeMigration = storage.raw;
storage.raw = JSON.stringify({schema: 2, revision: 5,
  items: [{id: 'n1', title: 'Read streams', archived: true}]});
const afterMigration = storage.raw;
oldTab.save('Read streams carefully');
console.log('before migration:', beforeMigration);
console.log('after migration:', afterMigration);
console.log('after stale save:', storage.raw);
````

## Fixtures

### triage-template.md

````
# Synthetic release incident
Observed trigger:
Confirmed impact and unknown scope:
Evidence preserved (schema, revision, build, original bytes):
Immediate containment for already-running clients:
Recovery choices requiring the user's decision:
Compatibility change for future clients:
Regression evidence:
Rollout and rollback conditions:
````

## Constraints

- Unknown future schemas must remain exportable as original bytes; do not reset them to an empty default.
- Never label a local read-then-write revision check an atomic cross-tab transaction.
- Do not silently choose between conflicting user titles during recovery.

## Acceptance evidence

- The future-compatible client refuses unsupported schema writes and preserves its unsaved draft.
- Provide a rollout strategy that handles unmodified old tabs, such as an earlier compatibility bridge or separate versioned authoritative storage with explicit reconciliation.
- Keep archived:true and the stale tab title available for a deliberate recovery decision.
- Complete the triage template with evidence, uncertainty, containment, migration tests, and rollback conditions; include same-build and mixed-build cases.

## Focused repair lab

This case is a project investigation without an automated repair lab.

A passing focused lab does not complete the wider incident. Keep the original failing
input and event order, explain the cause, and demonstrate a nearby variation.

## Investigation record

Record reproduction, hypotheses and observations, root cause, fix, a test that fails
before and passes after, recovery, and remaining limitations. Portal investigation
notes stay in your browser and are included in My notebook → Export backup.
This public case packet does not include your notes.

## Further variation

Extend to an HTTP service with conditional revision writes. Specify conflicts the server can prevent and offline drafts still requiring reconciliation.

## References

- [MDN: Window storage event](https://developer.mozilla.org/en-US/docs/Web/API/Window/storage_event)
- [MDN: Using IndexedDB](https://developer.mozilla.org/en-US/docs/Web/API/IndexedDB_API/Using_IndexedDB)

## Clues — open only after your own attempt

1. A version label detects incompatibility only if the writer checks it before committing.
2. Decide whether deployment changes the old tab at all. Test the old function unchanged.
3. Separate migration from publication and preserve both source and migrated snapshots until compatibility and recovery have been verified.

## Debrief — compare after you have evidence

- The rollback in this incident is performed by an old writer, not by the migration function. Testing migrations in isolation misses the lifecycle of a real release.
- Compatibility needs a deployment story. A guard added only in release 2 cannot discipline an existing release 1 tab. Versioned storage or a staged bridge changes the containment boundary; neither automatically resolves conflicting user edits.
