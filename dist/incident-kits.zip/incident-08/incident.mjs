function createLatestRequest(load) {
  let state = {status: 'idle', value: undefined, error: undefined};
  return {
    snapshot: () => ({...state}),
    run(input) {
      state = {status: 'pending', value: undefined, error: undefined};
      let result;
      try { result = load(input); } catch (error) { result = Promise.reject(error); }
      return Promise.resolve(result).then(
        value => { state = {status: 'success', value, error: undefined}; return value; },
        error => { state = {status: 'error', value: undefined, error}; throw error; }
      );
    }
  };
}
function deferred() {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return {promise, resolve, reject};
}
async function probe(rejectOld) {
  const gates = {old: deferred(), new: deferred()};
  const request = createLatestRequest(input => gates[input].promise);
  const old = request.run('old');
  const oldOutcome = old.then(value => ({value}), error => ({error: error.message}));
  const latest = request.run('new');
  gates.new.resolve('NEW');
  await latest;
  console.log('new settled:', request.snapshot().status, request.snapshot().value);
  if (rejectOld) gates.old.reject(new Error('obsolete failure'));
  else gates.old.resolve('OLD');
  console.log('old caller:', await oldOutcome);
  const state = request.snapshot();
  console.log('final screen:', state.status, state.value, state.error?.message);
}
await probe(false);
await probe(true);
