# incident-08 · The older search wins last

Stage 4 · after lesson-23 · approximately 55 minutes

Success and failure race against the current user intent

## Environment

Local Node.js 20.11+; run the starter as incident.mjs. Deferred promises control completion order; no timers, fetch calls, or arbitrary waiting are used.

All reports, logs, and data in this packet are synthetic. The starter is deliberately broken.
Read the environment and reproduction instructions before running it. Some packets require
assembling a browser or project experiment; they are not all standalone executables.

## Report

Synthetic incident: a user searches for an old term, immediately corrects it, and sees the correct results briefly. A late response then replaces them. On another attempt, an obsolete request fails and turns the newer successful screen into an error. Trace request ownership independently from completion order and protect the displayed state without hiding either caller’s own result.

## Evidence

### Controlled sequence

````
Start old, start new, resolve new, then settle old. The current implementation ends with OLD success or an obsolete error, depending on the last settlement.
````

### Boundary

````
The supplied loader is an ordinary promise-returning function. It does not promise cancellation, and a late result remains possible even if a separate transport supports abort.
````

## Reproduce

1. Run both controlled probes and compare final screen state with the old caller’s independent outcome.
2. Add the supplied matrix cases using deferred promises, resolving or rejecting only when the scenario says to.
3. Check state immediately after a new run and after each relevant settlement.

## Inherited code

````javascript
function createLatestRequest(load) {
  let state = {status: 'idle', value: undefined, error: undefined};
  return {
    snapshot: () => ({...state}),
    run(input) {
      state = {status: 'pending', value: undefined, error: undefined};
      let result;
      try { result = load(input); } catch (error) { result = Promise.reject(error); }
      return Promise.resolve(result).then(
        value => { state = {status: 'success', value, error: undefined}; return value; },
        error => { state = {status: 'error', value: undefined, error}; throw error; }
      );
    }
  };
}
function deferred() {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return {promise, resolve, reject};
}
async function probe(rejectOld) {
  const gates = {old: deferred(), new: deferred()};
  const request = createLatestRequest(input => gates[input].promise);
  const old = request.run('old');
  const oldOutcome = old.then(value => ({value}), error => ({error: error.message}));
  const latest = request.run('new');
  gates.new.resolve('NEW');
  await latest;
  console.log('new settled:', request.snapshot().status, request.snapshot().value);
  if (rejectOld) gates.old.reject(new Error('obsolete failure'));
  else gates.old.resolve('OLD');
  console.log('old caller:', await oldOutcome);
  const state = request.snapshot();
  console.log('final screen:', state.status, state.value, state.error?.message);
}
await probe(false);
await probe(true);
````

## Fixtures

### request-matrix.txt

````
A starts; B starts; B succeeds; A succeeds -> screen keeps B.
A starts; B starts; B succeeds; A fails -> screen keeps B.
A starts; B starts; A succeeds; B fails -> screen shows B failure.
The loader throws synchronously -> run returns a rejected promise.
A new run starts after success -> pending state clears old value and error.
Mutating a returned snapshot's status does not change the internal status.
````

## Constraints

- Keep createLatestRequest(load), run(input), and snapshot() from lab-53.
- Only the latest-started run may publish success or error; each run still preserves its own result or rejection.
- Do not treat abort support as the proof that obsolete completions cannot arrive.

## Acceptance evidence

- Both probes finish with NEW success while the old caller receives OLD or its original error.
- Latest failures remain visible; stale failures cannot overwrite newer state.
- Starting a run clears value and error; snapshots are fresh objects.
- The loader is invoked synchronously; a synchronous throw becomes an observable rejected run promise without escaping run().

## Focused repair lab

Open `#/lab/lab-53` in the portal.

A passing focused lab does not complete the wider incident. Keep the original failing
input and event order, explain the cause, and demonstrate a nearby variation.

## Investigation record

Record reproduction, hypotheses and observations, root cause, fix, a test that fails
before and passes after, recovery, and remaining limitations. Portal investigation
notes stay in your browser and are included in My notebook → Export backup.
This public case packet does not include your notes.

## Further variation

Add cooperative AbortController support. As a distinct challenge, model a server accepting a write while its acknowledgement is lost; investigate idempotency keys before retrying that side effect.

## References

- [MDN: AbortController](https://developer.mozilla.org/en-US/docs/Web/API/AbortController)

## Clues — open only after your own attempt

1. Assign ownership when a request starts, before calling the loader.
2. Apply the ownership check to both fulfillment and rejection branches.
3. Use a monotonically changing request token; keep publication decisions separate from the promise returned to each caller.

## Debrief — compare after you have evidence

- Completion order is an environmental fact; current intent is an application policy. Keeping those concepts separate prevents old work from taking ownership of the screen.
- Cancellation can reduce wasted work, but stale-result gating remains useful when an adapter ignores cancellation or a completion is already queued. Suppressing publication must not silently convert the caller’s failed request into success.
